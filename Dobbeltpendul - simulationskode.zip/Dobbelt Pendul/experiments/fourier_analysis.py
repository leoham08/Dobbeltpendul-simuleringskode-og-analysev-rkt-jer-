import matplotlib.pyplot as plt
import numpy as np

from double_pendulum.parameters import PendulumParameters
from double_pendulum.state import SimulationData
from time_series import get_y_values


MAX_DISPLAY_FREQUENCY = 5.0


def calculate_fourier_spectrum(
    time: np.ndarray,
    values: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Calculate the one-sided amplitude spectrum with an explicit FFT."""
    if len(time) != len(values) or len(time) < 2:
        raise ValueError("time and values must have the same length and at least two samples")

    time_step = float(np.median(np.diff(time)))
    centered_values = values - np.mean(values)
    window = np.hanning(len(centered_values))
    windowed_values = centered_values * window
    frequencies = np.fft.rfftfreq(len(windowed_values), d=time_step)
    transform = np.fft.rfft(windowed_values)
    amplitudes = 2.0 * np.abs(transform) / np.sum(window)
    amplitudes[0] /= 2.0
    return frequencies, amplitudes


def plot_fourier_spectrum(
    data: SimulationData,
    parameters: PendulumParameters,
    show: bool = True,
) -> None:
    """Plot the positive-frequency amplitude spectrum for one data variable."""
    variable_name = parameters.output_variable
    values, y_label = get_y_values(data, variable_name)
    frequencies, amplitudes = calculate_fourier_spectrum(data.time, values)
    display_mask = frequencies <= MAX_DISPLAY_FREQUENCY

    figure, axis = plt.subplots(figsize=(10, 5))
    axis.plot(frequencies[display_mask], amplitudes[display_mask])
    axis.set_xlabel("Frekvens [Hz]")
    axis.set_ylabel("Amplitude")
    axis.set_title(f"Fourieranalyse af {variable_name}")
    axis.grid(True, alpha=0.25)
    figure.tight_layout()
    if show:
        plt.show()


if __name__ == "__main__":
    from simulation_setup import run_simulation

    parameters, data = run_simulation()
    plot_fourier_spectrum(data, parameters)
