import matplotlib.pyplot as plt

from double_pendulum import PendulumParameters, simulate
from double_pendulum.state import SimulationData


def get_y_values(data: SimulationData, variable_name: str):
    variables = {
        "theta_1": (data.theta_1, r"$\theta_1$ [rad]"),
        "theta_2": (data.theta_2, r"$\theta_2$ [rad]"),
        "omega_1": (data.omega_1, r"$\omega_1$ [rad/s]"),
        "omega_2": (data.omega_2, r"$\omega_2$ [rad/s]"),
        "energy": (data.energy, "Energi [J]"),
        "potential_energy": (data.potential_energy, "Potentiel energi [J]"),
    }
    try:
        return variables[variable_name]
    except KeyError as error:
        available_variables = ", ".join(variables)
        raise ValueError(
            f"Ukendt variabel '{variable_name}'. Vælg en af: {available_variables}"
        ) from error


def plot_time_series(
    data: SimulationData,
    parameters: PendulumParameters,
    show: bool = True,
) -> None:
    """Create one time-series plot from an existing simulation."""
    variable_name = parameters.output_variable
    y_values, y_label = get_y_values(data, variable_name)

    figure, axis = plt.subplots(figsize=(10, 5))
    axis.plot(data.time, y_values)
    axis.set_xlabel("Tid [s]")
    axis.set_ylabel(y_label)
    axis.set_title(f"{variable_name} som funktion af tid")
    axis.grid(True, alpha=0.25)
    figure.tight_layout()
    if show:
        plt.show()


if __name__ == "__main__":
    from simulation_setup import run_simulation

    parameters, data = run_simulation()
    plot_time_series(data, parameters)
