import numpy as np
from pathlib import Path

from double_pendulum import PendulumParameters, simulate
from double_pendulum import parameters as parameter_module
from double_pendulum.state import SimulationData


def run_simulation() -> tuple[PendulumParameters, SimulationData]:
    """Create the shared 120-second simulation data set."""
    parameters = PendulumParameters()
    print(f"Parameterfil: {Path(parameter_module.__file__).resolve()}")
    print(
        "Startbetingelser: "
        f"theta_1_0={np.rad2deg(parameters.theta_1_0):.3f} grader, "
        f"theta_2_0={np.rad2deg(parameters.theta_2_0):.3f} grader, "
        f"omega_1_0={parameters.omega_1_0:.3f} rad/s, "
        f"omega_2_0={parameters.omega_2_0:.3f} rad/s"
    )
    print(f"Outputvariabel: {parameters.output_variable}")
    print(f"Simulationstid: {parameters.simulation_duration:.1f} sekunder")
    data = simulate(
        parameters,
        duration=parameters.simulation_duration,
        step_size=parameters.simulation_step_size,
    )
    return parameters, data
