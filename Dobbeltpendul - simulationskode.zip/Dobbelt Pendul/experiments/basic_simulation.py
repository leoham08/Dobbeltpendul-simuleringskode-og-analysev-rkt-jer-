from pathlib import Path

import matplotlib.pyplot as plt

from double_pendulum.visualization import animate, plot_overview
from fourier_analysis import plot_fourier_spectrum
from simulation_setup import run_simulation
from sonification import create_sonification
from time_series import plot_time_series


parameters, data = run_simulation()
data.save(Path("double_pendulum_data.npz"))
audio_path = create_sonification(data, parameters)
plot_overview(data, show=False)
animate(data, show=False)
plot_time_series(data, parameters, show=False)
plot_fourier_spectrum(data, parameters, show=False)

plt.show()
print(f"Lyd gemt: {audio_path}")
print(f"Graf og lyd bruger: {parameters.output_variable}")
