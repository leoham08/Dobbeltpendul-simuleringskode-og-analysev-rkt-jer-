import json
import wave
from dataclasses import asdict
from pathlib import Path

import numpy as np

from double_pendulum.parameters import PendulumParameters
from double_pendulum.state import SimulationData


AUDIO_DURATION = 30.0
SAMPLE_RATE = 44_100
MIN_FREQUENCY = 220.0
MAX_FREQUENCY = 880.0
MIN_PHYSICAL_FREQUENCY = 0.1
MAX_PHYSICAL_FREQUENCY = 2.0

OUTPUT_DIRECTORY = Path(__file__).resolve().parents[1] / "audio"


def get_output_values(data: SimulationData, variable_name: str) -> np.ndarray:
    variables = {
        "theta_1": data.theta_1,
        "theta_2": data.theta_2,
        "omega_1": data.omega_1,
        "omega_2": data.omega_2,
        "energy": data.energy,
        "potential_energy": data.potential_energy,
    }
    try:
        return variables[variable_name]
    except KeyError as error:
        available_variables = ", ".join(variables)
        raise ValueError(
            f"Ukendt output_variable '{variable_name}'. Vælg en af: {available_variables}"
        ) from error


def estimate_dominant_frequency(
    simulation_time: np.ndarray,
    signal: np.ndarray,
) -> float:
    """Estimate the strongest non-zero frequency component in the signal."""
    time_step = float(np.median(np.diff(simulation_time)))
    centered_signal = signal - np.mean(signal)
    windowed_signal = centered_signal * np.hanning(len(centered_signal))
    frequencies = np.fft.rfftfreq(len(windowed_signal), time_step)
    spectrum = np.abs(np.fft.rfft(windowed_signal))
    dominant_index = 1 + np.argmax(spectrum[1:])
    return float(frequencies[dominant_index])


def map_physical_frequency_to_audio(
    physical_frequency: float,
    minimum_frequency: float = MIN_FREQUENCY,
    maximum_frequency: float = MAX_FREQUENCY,
) -> float:
    """Map one physical frequency logarithmically to one audible frequency."""
    clipped_frequency = np.clip(
        physical_frequency,
        MIN_PHYSICAL_FREQUENCY,
        MAX_PHYSICAL_FREQUENCY,
    )
    normalized_frequency = (
        np.log(clipped_frequency) - np.log(MIN_PHYSICAL_FREQUENCY)
    ) / (np.log(MAX_PHYSICAL_FREQUENCY) - np.log(MIN_PHYSICAL_FREQUENCY))
    return minimum_frequency * (
        maximum_frequency / minimum_frequency
    ) ** normalized_frequency


def make_audio_signal(
    frequency: float,
    audio_duration: float = AUDIO_DURATION,
    sample_rate: int = SAMPLE_RATE,
) -> np.ndarray:
    """Synthesize one pure sine tone at a constant frequency."""
    sample_count = int(round(audio_duration * sample_rate))
    audio_time = np.arange(sample_count, dtype=float) / sample_rate
    signal = 0.8 * np.sin(2 * np.pi * frequency * audio_time)

    fade_samples = min(sample_rate // 20, sample_count // 2)
    fade = np.ones(sample_count)
    fade[:fade_samples] = np.linspace(0.0, 1.0, fade_samples)
    fade[-fade_samples:] = np.linspace(1.0, 0.0, fade_samples)
    return signal * fade


def write_wav(path: Path, signal: np.ndarray, sample_rate: int) -> None:
    """Write a mono floating-point signal as 16-bit PCM WAV."""
    pcm_signal = np.asarray(np.clip(signal, -1.0, 1.0) * 32767, dtype=np.int16)
    with wave.open(str(path), "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(pcm_signal.tobytes())


def create_sonification(
    data: SimulationData,
    parameters: PendulumParameters,
    audio_duration: float = AUDIO_DURATION,
) -> Path:
    """Create audio directly from an existing simulation data set."""
    source_variable = parameters.output_variable
    source_values = get_output_values(data, source_variable)
    physical_frequency = estimate_dominant_frequency(data.time, source_values)
    audio_frequency = map_physical_frequency_to_audio(physical_frequency)
    signal = make_audio_signal(audio_frequency, audio_duration)
    audio_path = OUTPUT_DIRECTORY / f"double_pendulum_{source_variable}.wav"
    metadata_path = OUTPUT_DIRECTORY / f"double_pendulum_{source_variable}.json"

    OUTPUT_DIRECTORY.mkdir(exist_ok=True)
    write_wav(audio_path, signal, SAMPLE_RATE)
    metadata = {
        "source_variable": source_variable,
        "simulation_duration_seconds": float(data.time[-1]),
        "audio_duration_seconds": audio_duration,
        "time_compression_factor": float(data.time[-1]) / audio_duration,
        "simulation_step_seconds": float(np.median(np.diff(data.time))),
        "sample_rate_hz": SAMPLE_RATE,
        "minimum_frequency_hz": MIN_FREQUENCY,
        "maximum_frequency_hz": MAX_FREQUENCY,
        "physical_dominant_frequency_hz": physical_frequency,
        "audio_frequency_hz": audio_frequency,
        "mapping": f"dominant {source_variable} frequency mapped logarithmically to one pure tone",
        "parameters": asdict(parameters),
    }
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return audio_path


def main() -> None:
    from simulation_setup import run_simulation

    parameters, data = run_simulation()
    audio_path = create_sonification(data, parameters)
    from time_series import plot_time_series

    plot_time_series(data, parameters)
    print(f"Lyd gemt: {audio_path}")
    print(f"Metadata gemt: {audio_path.with_suffix('.json')}")


if __name__ == "__main__":
    main()
