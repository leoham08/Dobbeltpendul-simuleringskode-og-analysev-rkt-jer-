# Double Pendulum

En gennemsigtig, rent numerisk simulering af et klassisk dobbeltpendul.

## Installation

Fra projektmappen:

```text
python -m pip install -e .
```

## Kør en simulering

```text
python experiments/basic_simulation.py
```

Startbetingelserne, outputvariablen, simulationstiden og tidssteppet ændres i `src/double_pendulum/parameters.py`. Vinkler angives i radianer og måles fra den lodrette nedadgående retning. `potential_energy` kan vælges for at vise tyngdepotentialet for begge lodder.

Eksempel på centrale indstillinger:

```python
theta_1_0 = np.deg2rad(30.0)
theta_2_0 = np.deg2rad(20.0)
output_variable = "potential_energy"
simulation_duration = 120.0
simulation_step_size = 0.001
```

Alle grafer, Fourieranalysen, animationen og sonifikationen bruger disse værdier fra det samme parameterobjekt.

Simulationen kører i 120 sekunder, gemmer data i `double_pendulum_data.npz`, genererer sonifikation fra det samme datasæt og åbner fire vinduer samtidig: oversigtsgrafer, dobbeltpendul-animationen, det valgte tidsserieplot og et Fourier-spektrum.

## Enkelt tidsserieplot

Kør dette modul for én graf med tid på x-aksen:

```text
py experiments/time_series.py
```

Outputvariablen ændres i `parameters.py`, for eksempel `output_variable = "potential_energy"`. Den samme variabel vises på tidsserieplottet og sonificeres. Mulige værdier er `theta_1`, `theta_2`, `omega_1`, `omega_2`, `energy` og `potential_energy`. Modulet bruger den fælles 120-sekunders simulation.

## Sonifikation

Kør dette modul for at omdanne `theta_1` til en hørbar tone:

```text
py experiments/sonification.py
```

Sonifikationen bruger direkte det datasæt, som `basic_simulation.py` allerede har beregnet. En FFT finder den dominerende svingningsfrekvens i `theta_1`, og denne mappes én gang logaritmisk til 220-880 Hz. Resultatet er én konstant ren sinustone, ikke en tone der glider op og ned. De 120 sekunder komprimeres til 30 sekunders lyd. WAV-filen og metadata gemmes i `audio/`.

## Fourier-analyse

Fourieranalysen ligger i `experiments/fourier_analysis.py` og bruger den samme outputvariabel som `parameters.py`. Den viser amplituden som funktion af positiv frekvens i et separat vindue:

```text
py experiments/fourier_analysis.py
```

## Struktur

- `src/double_pendulum/physics.py`: De eksplicitte dobbeltpendul-ligninger og fysiske størrelser.
- `src/double_pendulum/integrators.py`: RK4-integratoren.
- `src/double_pendulum/simulation.py`: Tidsintegration og dataopsamling.
- `src/double_pendulum/visualization.py`: Matplotlib-grafer og animation.
- `experiments/simulation_setup.py`: Fælles 120-sekunders simulation for alle analyser.
- `experiments/fourier_analysis.py`: FFT-baseret frekvensanalyse og spektrumplot.
- `experiments/sonification.py`: Lydgenerering fra eksisterende simulationsdata.
- `experiments/time_series.py`: Enkelt tidsserieplot til videre analyse.
- `tests/`: Grundlæggende fysiske og numeriske tests.
