import unittest

import numpy as np

from double_pendulum import PendulumParameters, simulate
from double_pendulum.physics import angular_acceleration, observables


class PhysicsTests(unittest.TestCase):
    def test_vertical_rest_state_has_zero_angular_acceleration(self):
        parameters = PendulumParameters(theta_1_0=0.0, theta_2_0=0.0)
        acceleration = angular_acceleration(parameters.initial_state(), parameters)
        np.testing.assert_allclose(acceleration, [0.0, 0.0])

    def test_positions_have_expected_shape(self):
        parameters = PendulumParameters()
        positions, accelerations, energy, potential_energy, momentum = observables(
            parameters.initial_state(), parameters
        )
        self.assertEqual(positions.shape, (2, 2))
        self.assertEqual(accelerations.shape, (2, 2))
        self.assertEqual(energy.shape, (1,))
        self.assertEqual(potential_energy.shape, (1,))
        self.assertEqual(momentum.shape, (6,))

    def test_potential_energy_is_recorded_and_selectable(self):
        parameters = PendulumParameters(
            theta_1_0=0.2,
            theta_2_0=0.4,
            output_variable="potential_energy",
        )
        data = simulate(parameters, duration=0.02, step_size=0.001)
        expected_initial_energy = (
            parameters.mass_1 * parameters.gravity * data.positions[0, 0, 1]
            + parameters.mass_2 * parameters.gravity * data.positions[0, 1, 1]
        )
        self.assertAlmostEqual(data.potential_energy[0], expected_initial_energy)
        self.assertEqual(parameters.output_variable, "potential_energy")

    def test_energy_is_nearly_conserved_for_short_simulation(self):
        data = simulate(PendulumParameters(theta_1_0=0.3, theta_2_0=0.2), duration=2.0, step_size=0.001)
        relative_change = np.max(np.abs(data.energy - data.energy[0])) / abs(data.energy[0])
        self.assertLess(relative_change, 1e-7)


if __name__ == "__main__":
    unittest.main()
