import numpy as np

from .parameters import PendulumParameters


def angular_acceleration(state: np.ndarray, parameters: PendulumParameters) -> np.ndarray:
    """Calculate angular accelerations from the double-pendulum equations."""
    theta_1, theta_2, omega_1, omega_2 = state
    length_1 = parameters.length_1
    length_2 = parameters.length_2
    mass_1 = parameters.mass_1
    mass_2 = parameters.mass_2
    gravity = parameters.gravity
    difference = theta_1 - theta_2
    denominator = 2 * mass_1 + mass_2 - mass_2 * np.cos(2 * difference)

    alpha_1 = (
        -gravity * (2 * mass_1 + mass_2) * np.sin(theta_1)
        - mass_2 * gravity * np.sin(theta_1 - 2 * theta_2)
        - 2
        * np.sin(difference)
        * mass_2
        * (omega_2**2 * length_2 + omega_1**2 * length_1 * np.cos(difference))
    ) / (length_1 * denominator)

    alpha_2 = (
        2
        * np.sin(difference)
        * (
            omega_1**2 * length_1 * (mass_1 + mass_2)
            + gravity * (mass_1 + mass_2) * np.cos(theta_1)
            + omega_2**2 * length_2 * mass_2 * np.cos(difference)
        )
    ) / (length_2 * denominator)

    return np.array([alpha_1, alpha_2])


def derivatives(time: float, state: np.ndarray, parameters: PendulumParameters) -> np.ndarray:
    """Return d/dt [theta_1, theta_2, omega_1, omega_2]."""
    del time
    alpha_1, alpha_2 = angular_acceleration(state, parameters)
    return np.array([state[2], state[3], alpha_1, alpha_2])


def observables(state: np.ndarray, parameters: PendulumParameters) -> tuple[np.ndarray, ...]:
    """Calculate positions, Cartesian accelerations, energy and momentum."""
    theta_1, theta_2, omega_1, omega_2 = state
    length_1 = parameters.length_1
    length_2 = parameters.length_2
    mass_1 = parameters.mass_1
    mass_2 = parameters.mass_2
    alpha_1, alpha_2 = angular_acceleration(state, parameters)

    position_1 = np.array([length_1 * np.sin(theta_1), -length_1 * np.cos(theta_1)])
    position_2 = position_1 + np.array([length_2 * np.sin(theta_2), -length_2 * np.cos(theta_2)])
    velocity_1 = np.array([
        length_1 * np.cos(theta_1) * omega_1,
        length_1 * np.sin(theta_1) * omega_1,
    ])
    velocity_2 = velocity_1 + np.array([
        length_2 * np.cos(theta_2) * omega_2,
        length_2 * np.sin(theta_2) * omega_2,
    ])
    acceleration_1 = np.array([
        length_1 * (np.cos(theta_1) * alpha_1 - np.sin(theta_1) * omega_1**2),
        length_1 * (np.sin(theta_1) * alpha_1 + np.cos(theta_1) * omega_1**2),
    ])
    acceleration_2 = acceleration_1 + np.array([
        length_2 * (np.cos(theta_2) * alpha_2 - np.sin(theta_2) * omega_2**2),
        length_2 * (np.sin(theta_2) * alpha_2 + np.cos(theta_2) * omega_2**2),
    ])

    kinetic_energy = 0.5 * mass_1 * np.dot(velocity_1, velocity_1) + 0.5 * mass_2 * np.dot(velocity_2, velocity_2)
    potential_energy = mass_1 * parameters.gravity * position_1[1] + mass_2 * parameters.gravity * position_2[1]
    energy = np.array([kinetic_energy + potential_energy])
    potential_energy = np.array([potential_energy])
    momentum = np.concatenate((mass_1 * velocity_1, mass_2 * velocity_2, mass_1 * velocity_1 + mass_2 * velocity_2))

    return (
        np.stack((position_1, position_2)),
        np.stack((acceleration_1, acceleration_2)),
        energy,
        potential_energy,
        momentum,
    )
