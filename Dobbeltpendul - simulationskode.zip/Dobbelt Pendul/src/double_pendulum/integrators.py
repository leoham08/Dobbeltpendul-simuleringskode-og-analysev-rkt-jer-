from collections.abc import Callable

import numpy as np


DerivativeFunction = Callable[[float, np.ndarray], np.ndarray]


def rk4_step(
    derivative: DerivativeFunction,
    time: float,
    state: np.ndarray,
    step_size: float,
) -> np.ndarray:
    """Advance one fixed time step with classical fourth-order Runge-Kutta."""
    k_1 = derivative(time, state)
    k_2 = derivative(time + step_size / 2, state + step_size * k_1 / 2)
    k_3 = derivative(time + step_size / 2, state + step_size * k_2 / 2)
    k_4 = derivative(time + step_size, state + step_size * k_3)
    return state + step_size * (k_1 + 2 * k_2 + 2 * k_3 + k_4) / 6
