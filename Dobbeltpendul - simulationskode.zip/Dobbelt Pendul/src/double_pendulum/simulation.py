import numpy as np

from .integrators import rk4_step
from .parameters import PendulumParameters
from .physics import derivatives, observables
from .state import SimulationData


def simulate(
    parameters: PendulumParameters,
    duration: float = 20.0,
    step_size: float = 0.005,
) -> SimulationData:
    """Integrate the pendulum and record all requested physical quantities."""
    if duration <= 0 or step_size <= 0:
        raise ValueError("duration and step_size must be positive")

    number_of_steps = int(np.ceil(duration / step_size))
    time = np.arange(number_of_steps + 1, dtype=float) * step_size
    time[-1] = duration
    state = np.empty((number_of_steps + 1, 4), dtype=float)
    positions = np.empty((number_of_steps + 1, 2, 2), dtype=float)
    accelerations = np.empty((number_of_steps + 1, 2, 2), dtype=float)
    energy = np.empty(number_of_steps + 1, dtype=float)
    potential_energy = np.empty(number_of_steps + 1, dtype=float)
    momentum = np.empty((number_of_steps + 1, 6), dtype=float)

    current_state = parameters.initial_state()
    for index, current_time in enumerate(time):
        state[index] = current_state
        (
            current_positions,
            current_accelerations,
            current_energy,
            current_potential_energy,
            current_momentum,
        ) = observables(current_state, parameters)
        positions[index] = current_positions
        accelerations[index] = current_accelerations
        energy[index] = current_energy[0]
        potential_energy[index] = current_potential_energy[0]
        momentum[index] = current_momentum
        if index < number_of_steps:
            current_step = time[index + 1] - current_time
            current_state = rk4_step(
                lambda t, values: derivatives(t, values, parameters),
                current_time,
                current_state,
                current_step,
            )

    return SimulationData(
        time,
        state,
        positions,
        accelerations,
        energy,
        potential_energy,
        momentum,
    )
