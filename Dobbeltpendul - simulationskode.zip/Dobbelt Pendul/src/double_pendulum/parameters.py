from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class PendulumParameters:
    """Physical constants and initial conditions.

    Angles are measured from the downward vertical in radians.
    """

    length_1: float = 1.0
    length_2: float = 1.0
    mass_1: float = 1.0
    mass_2: float = 1.0
    gravity: float = 9.82
    theta_1_0: float = np.deg2rad(10.0)
    theta_2_0: float = np.deg2rad(110.0)
    omega_1_0: float = 0.0
    omega_2_0: float = 0.0
    output_variable: str = "potential_energy"
    simulation_duration: float = 120.0
    simulation_step_size: float = 0.001

    def __post_init__(self) -> None:
        valid_output_variables = {
            "theta_1",
            "theta_2",
            "omega_1",
            "omega_2",
            "energy",
            "potential_energy",
        }
        if self.output_variable not in valid_output_variables:
            available = ", ".join(sorted(valid_output_variables))
            raise ValueError(
                f"Ukendt output_variable '{self.output_variable}'. Vælg en af: {available}"
            )
        if self.simulation_duration <= 0 or self.simulation_step_size <= 0:
            raise ValueError("simulation_duration and simulation_step_size must be positive")

    def initial_state(self) -> np.ndarray:
        """Return [theta_1, theta_2, omega_1, omega_2]."""
        return np.array(
            [self.theta_1_0, self.theta_2_0, self.omega_1_0, self.omega_2_0],
            dtype=float,
        )
