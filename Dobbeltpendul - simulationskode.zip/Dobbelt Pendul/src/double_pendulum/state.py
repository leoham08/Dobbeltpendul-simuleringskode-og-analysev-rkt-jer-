from dataclasses import dataclass

import numpy as np


@dataclass
class SimulationData:
    """Time series produced by a simulation."""

    time: np.ndarray
    state: np.ndarray
    positions: np.ndarray
    accelerations: np.ndarray
    energy: np.ndarray
    potential_energy: np.ndarray
    momentum: np.ndarray

    @property
    def theta_1(self) -> np.ndarray:
        return self.state[:, 0]

    @property
    def theta_2(self) -> np.ndarray:
        return self.state[:, 1]

    @property
    def omega_1(self) -> np.ndarray:
        return self.state[:, 2]

    @property
    def omega_2(self) -> np.ndarray:
        return self.state[:, 3]

    def save(self, path: str) -> None:
        """Save all recorded arrays in NumPy's portable .npz format."""
        np.savez(
            path,
            time=self.time,
            state=self.state,
            positions=self.positions,
            accelerations=self.accelerations,
            energy=self.energy,
            potential_energy=self.potential_energy,
            momentum=self.momentum,
        )
