import matplotlib.pyplot as plt
import numpy as np

from .state import SimulationData


def plot_overview(data: SimulationData, show: bool = True) -> None:
    """Plot the main time series without changing the simulation data."""
    figure, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    axes[0].plot(data.time, data.theta_1, label=r"$\theta_1$")
    axes[0].plot(data.time, data.theta_2, label=r"$\theta_2$")
    axes[0].set_ylabel("Vinkel [rad]")
    axes[0].legend()

    axes[1].plot(data.time, data.omega_1, label=r"$\omega_1$")
    axes[1].plot(data.time, data.omega_2, label=r"$\omega_2$")
    axes[1].set_ylabel("Vinkelhastighed [rad/s]")
    axes[1].legend()

    relative_energy_deviation = 100 * (data.energy - data.energy[0]) / abs(data.energy[0])
    axes[2].plot(data.time, relative_energy_deviation)
    axes[2].set_xlabel("Tid [s]")
    axes[2].set_ylabel("Relativ energiafvigelse [%]")
    axes[2].set_title("Mekanisk energi relativt til startenergien")
    figure.tight_layout()
    if show:
        plt.show()


def animate(
    data: SimulationData,
    playback_speed: float = 1.0,
    target_fps: int = 60,
    show: bool = True,
) -> None:
    """Animate the two pendulum rods at a chosen multiple of real time."""
    if playback_speed <= 0 or target_fps <= 0:
        raise ValueError("playback_speed and target_fps must be positive")

    time_step = float(np.median(np.diff(data.time)))
    frames_per_update = max(1, round(1 / (target_fps * time_step)))
    frame_indices = range(0, len(data.time), frames_per_update)
    interval = 1000 * time_step * frames_per_update / playback_speed

    figure, axis = plt.subplots(figsize=(6, 6))
    maximum_distance = float(np.max(np.abs(data.positions)))
    limit = max(1.25 * maximum_distance, 1.0)
    axis.set_xlim(-limit, limit)
    axis.set_ylim(-limit, limit)
    axis.set_aspect("equal")
    axis.grid(True, alpha=0.25)
    line, = axis.plot([], [], "o-", linewidth=2)

    def update(index: int):
        points = data.positions[index]
        line.set_data([0.0, points[0, 0], points[1, 0]], [0.0, points[0, 1], points[1, 1]])
        return (line,)

    from matplotlib.animation import FuncAnimation

    animation = FuncAnimation(
        figure,
        update,
        frames=frame_indices,
        interval=interval,
        blit=True,
    )
    figure.animation = animation
    if show:
        plt.show()
