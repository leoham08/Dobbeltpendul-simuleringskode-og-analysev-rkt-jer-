"""Numerical tools for studying a classical double pendulum."""

from .parameters import PendulumParameters
from .simulation import simulate

__all__ = ["PendulumParameters", "simulate"]
